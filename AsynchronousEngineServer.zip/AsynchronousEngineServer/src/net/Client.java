package net;


import main.SystemHelper;

import main.SystemHelper;

import java.io.BufferedReader;
import java.io.DataOutputStream;

public class Client {

    private String clientSentence;

    public Client (BufferedReader in, DataOutputStream out) {
        try {
            clientSentence = in.readLine();
            SystemHelper.print("Established a connection with a client:");
            SystemHelper.print("Received Handshake Word: " + clientSentence);
            SystemHelper.print("Sending Response Word: "+clientSentence.toUpperCase());
            out.writeBytes(clientSentence.toUpperCase() + '\n');
        } catch (Exception e) {
            System.err.println("Internal Error Related to Client Creation:");
            e.printStackTrace();
        }
    }

}
