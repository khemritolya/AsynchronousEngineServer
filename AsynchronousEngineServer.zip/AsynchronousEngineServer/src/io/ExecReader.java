package io;

import main.SystemHelper;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

/*
    (c) 2016, khemritolya

    This class allows us to determine and read the executable that should be sent to the client.

 */

public class ExecReader {

    public static byte[] readProgram(){
        try {
            //query input
            SystemHelper.print("Please enter the path to the TARGET FILE to be run by the user: ");
            Scanner scan = new Scanner(System.in);

            //read result
            return Files.readAllBytes(Paths.get(scan.nextLine()));
        } catch (Exception e) {
            System.err.println("Unable to read file");
            e.printStackTrace();
            return null;
        }
    }
}
