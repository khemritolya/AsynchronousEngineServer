package io;

import java.nio.file.Files;
import java.nio.file.Paths;

public class ExecReader {

    public static byte[] readProgram(){
        try {
            return Files.readAllBytes(Paths.get(Files.readAllLines(Paths.get("/home/khemri/Desktop/AsynchronousEngineServer/src/io/target.txt")).get(0)));
        } catch (Exception e) {
            System.err.println("Unable to read file");
            e.printStackTrace();
            return null;
        }
    }
}
