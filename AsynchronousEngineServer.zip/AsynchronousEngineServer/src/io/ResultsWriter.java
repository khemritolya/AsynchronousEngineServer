package io;

import client.Client;

public class ResultsWriter {

    public static void writeResult(Client client) {

    }
}
