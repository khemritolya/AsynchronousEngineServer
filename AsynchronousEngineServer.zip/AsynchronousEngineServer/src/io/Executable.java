package io;

public class Executable {

    private String result;

    public Executable(String file){

    }

    public String getResult() { return result; }
}
