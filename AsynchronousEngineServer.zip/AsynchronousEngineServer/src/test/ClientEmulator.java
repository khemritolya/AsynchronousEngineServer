package test;

import java.net.*;
import java.io.*;

public class ClientEmulator {
    public static void main(String[] cmdl) {
        String word = "handshake";
        try {
            Socket clientSocket = new Socket();
            clientSocket.connect(new InetSocketAddress("localhost", 6789), 10000);

            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            outToServer.writeBytes(word + '\n');
            String res = inFromServer.readLine();
            if (word.toUpperCase().equals(res))
                System.out.println("Contact Established");

        } catch (Exception E) {
            E.printStackTrace();
        }
    }
}
