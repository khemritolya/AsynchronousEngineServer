package test;

import java.net.*;
import java.io.*;

public class ClientEmulator {
    public static void main(String[] cmdl) {
        String word = "ADBAWGD381737adjklJDW*72elkdW";
        try {
            Socket clientSocket = new Socket();
            clientSocket.connect(new InetSocketAddress("172.21.38.108", 6789), 10000);

            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            outToServer.writeBytes("CLIENT EMULATOR" + '\n');
            outToServer.writeBytes(word+'\n');
            String res = inFromServer.readLine();
            if (word.toUpperCase().equals(res))
                System.out.println("Contact Established - Server responded with handshake string: "+res);


        } catch (Exception E) {
            E.printStackTrace();
        }
    }
}
