package test;

import java.net.*;
import java.io.*;

/*
    (c) 2016, khemritolya

    This is a really really really really messy implementation of a client emulator.

    I use it to make sure connections work, it would not recommend anyone using it besides that.

    It has all sorts of bad practice, so don't use it to teach yourself anything either.
    This is why I didn't bother annotating it.

 */

public class ClientEmulator {
    public static void main(String[] cmdl) {
        String word = "ADBAWGD381737adjklJDW*72elkdW";
        try {
            Socket clientSocket = new Socket();
            clientSocket.connect(new InetSocketAddress("localhost", 6789), 10000);

            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            outToServer.writeBytes("CLIENT EMULATOR" + '\n');
            outToServer.writeBytes(word+'\n');
            String res = inFromServer.readLine();
            if (word.toUpperCase().equals(res))
                System.out.println("Contact Established - Server responded with handshake string: "+res);
            while (1 == 1) {
                System.out.println(inFromServer.readLine());
            }

        } catch (Exception E) {
            E.printStackTrace();
        }
    }
}
