package main;

import io.ExecReader;

public class Launcher {

    public static void main(String args[]) throws Exception
    {
        SystemHelper.print("Launching AsynchronousEngine Server " + SystemHelper.VERSION_CODE);
        SystemHelper.print("Reading Executable...");
        byte[] program = ExecReader.readProgram();
        SystemHelper.print("Starting TCP Server...");
        ServerController.launch(program);
    }

}
