package main;

import io.ExecReader;

import java.net.Inet4Address;
import java.net.InetAddress;

/*
    (c) 2016, khemritolya

    This class is where it all starts.

    It more or less just prints the welcome message, and then launches the server,
    after telling the ExecHandler to read the executable.

    It does nothing besides that.

    This is not the class you are looking for. Move along.

 */

public class Launcher {

    public static void main(String args[]) throws Exception
    {

        SystemHelper.print("Launching AsynchronousEngine Server " + SystemHelper.VERSION_CODE);

        //file reader TBD
        //SystemHelper.print("Commencing executable setup...");
        //byte[] program = ExecReader.readProgram();

        //server
        SystemHelper.print("Commencing TCP server setup...");
        ServerController.launch();
    }

}
