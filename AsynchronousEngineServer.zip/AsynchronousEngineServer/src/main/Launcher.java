package main;

public class Launcher {

    public static void main(String args[]) throws Exception
    {
        SystemHelper.print("Launching AsynchronousEngine Server " + SystemHelper.VERSION_CODE);
        SystemHelper.print("Compiling Executable...NOT IMPLEMENTED");
        SystemHelper.print("Starting TCP Server...");
        ServerController.launch();
    }

}
