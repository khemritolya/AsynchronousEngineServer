package main;

import client.*;

import java.net.*;
import java.io.*;
import java.util.Scanner;

/*
    (c) 2016, khemritolya

    This class handles all incoming traffic and creates a thread for that connection.

    All subsequent communication is handled in the "Client" class.
    The thread is created in the form of a "ClientExtender" object.

 */

public class ServerController {

    public static void launch() {
        try {

            //create the socket

            Scanner scanner = new Scanner(System.in);
            SystemHelper.print("Please enter the PORT to be used:");
            int port = scanner.nextInt();
            SystemHelper.print("Please enter the range per client:");
            int range = scanner.nextInt();

            ServerSocket welcomeSocket = new ServerSocket(port);

            //update ip with php server BROKEN
            //AddressUpdater.updateIP(port);

            //needed to fool compiler
            boolean quit = false;

            //hello message
            SystemHelper.print("ServerController Initiated...");

            //network prints
            SystemHelper.print("Connection Data for:");
            SystemHelper.print("Your IP: "+SystemHelper.getIpAddress());
            SystemHelper.print("Connection is on port: "+port);

            //done setting up
            SystemHelper.print("Waiting for a client to connect...");
            int i = 0;

            //scan for connections and handle them
            while(!quit) {
                Socket connectionSocket = welcomeSocket.accept();

                //create the new thread + object (I KNOW the constructor is a horrible mess)
                new ClientExtender(new BufferedReader(new InputStreamReader(connectionSocket.getInputStream())),
                        new DataOutputStream(connectionSocket.getOutputStream()), range*i, range*(i+1), i+"").start();

                //notify the user of creation (also doubles as proof of multi-threading)
                SystemHelper.print("Started a new ClientExtender with id: "+i);
                SystemHelper.print("The program has created "+(i+1)+" ClientExtender(s)");
                i++;
            }

            //close the socket (never actually reached but needed anyways???)
            welcomeSocket.close();

        } catch (Exception e) {
            System.err.println("Internal Error in Server Controller: ");
            e.printStackTrace();
        }
    }
}
