package main;

import util.Client;

import java.net.*;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ServerController {

    private static List<Client> clientList = new ArrayList<>();
    private static Map<Client, String> idMap = new HashMap<>();

    public static void launch(byte[] program) {
        try {

            ServerSocket welcomeSocket = new ServerSocket(6789);

            //needed to fool compiler
            boolean quit = false;

	
            SystemHelper.print("ServerController Initiated");

            String clientSentence;

            //scan for connections and handle them
            while(!quit) {
                Socket connectionSocket = welcomeSocket.accept();

                Client client = new Client(
                        new BufferedReader(new InputStreamReader(connectionSocket.getInputStream())),
                        new DataOutputStream(connectionSocket.getOutputStream()), 500, -9990, program);

                clientList.add(client);


            }

            //close the socket (never actually reached but needed anyways)
            welcomeSocket.close();

        } catch (Exception e) {
            System.err.println("Internal Error in Server Controller: ");
            e.printStackTrace();
        }
    }
}
