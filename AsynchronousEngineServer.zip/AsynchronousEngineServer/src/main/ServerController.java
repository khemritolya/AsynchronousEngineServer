package main;

import net.Client;

import java.net.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ServerController {

    private static List<Client> clientList = new ArrayList<>();

    public static void launch() {
        try {

            ServerSocket welcomeSocket = new ServerSocket(6789);

            //needed to fool compiler
            boolean quit = false;

            SystemHelper.print("ServerController Initiated");

            String clientSentence;

            //scan for connections and handle them
            while(!quit) {
                Socket connectionSocket = welcomeSocket.accept();

                clientList.add(new Client(
                        new BufferedReader(new InputStreamReader(connectionSocket.getInputStream())),
                        new DataOutputStream(connectionSocket.getOutputStream())));


            }

            //close the socket (never actually reached but needed anyways)
            welcomeSocket.close();

        } catch (Exception e) {
            System.err.println("Internal Error in Server Controller: ");
            e.printStackTrace();
        }
    }
}
