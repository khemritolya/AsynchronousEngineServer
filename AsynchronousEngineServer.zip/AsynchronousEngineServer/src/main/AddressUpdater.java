package main;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

//Currently not used b/c glitch in php code

public class AddressUpdater {
    public static void updateIP(int port) {
        try {
            String url = "http://www.expert700.me/newaddress.php";

            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            con.setRequestMethod("POST");
            String urlParameters = "port="+port+"&ipaddress=50.250.17.51";

            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();
            wr.close();

            SystemHelper.print("Response Code for connection: "+con.getResponseCode());
            SystemHelper.print("Response Message"+con.getResponseMessage());

        } catch (Exception e) {
            System.err.println("An error occured trying to connect to the PHP server!");
            e.printStackTrace();
        }
    }
}
