package main;

import javax.annotation.Resource;
import java.time.LocalDateTime;

public class SystemHelper {

    @Resource
    public static final String VERSION_CODE = "VERSION 0.10";

    public static void print(String in) {

        System.out.println("[SYSTEM HELPER "+ LocalDateTime.now()+" ] "+in);
    }
}
