package main;

import javax.annotation.Resource;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.time.LocalDateTime;

/*
    (c) 2016, khemritolya

    This class just has some little system utilities
    Besides that, it does nothing but make my typing faster

 */

public class SystemHelper {

    //globals
    @Resource
    public static final String VERSION_CODE = "VERSION 0.14";

    //make printing stuff easier
    public static void print(String in) {
        System.out.println("[SYSTEM HELPER "+ LocalDateTime.now()+"] "+in);
    }

    //make printing stuff easier
    public static void print(int in) {
        System.out.println("[SYSTEM HELPER "+ LocalDateTime.now()+"] "+in);
    }

    //get the ip address
    public static String getIpAddress() {
        URL myIP;
        try {
            myIP = new URL("http://api.externalip.net/ip/");

            BufferedReader in = new BufferedReader(new InputStreamReader(myIP.openStream()));
            String ip = in.readLine();
            if ( ip.equals(null) )
                throw new Exception("FATAL ERROR CONNECTION TO WEBSITE");
            throw new Exception();
        } catch (Exception e) {
            try {
                myIP = new URL("http://myip.dnsomatic.com/");

                BufferedReader in = new BufferedReader(new InputStreamReader(myIP.openStream()));
                String ip = in.readLine();
                if ( ip.equals(null) )
                    throw new Exception("FATAL ERROR CONNECTION TO WEBSITE");
                return ip;
            } catch (Exception e1) {
                try {
                    myIP = new URL("http://icanhazip.com/");

                    BufferedReader in = new BufferedReader(new InputStreamReader(myIP.openStream()));
                    String ip = in.readLine();
                    if ( ip.equals(null) )
                        throw new Exception("FATAL ERROR CONNECTION TO WEBSITE");
                    return ip;
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
        return "50.250.17.51";
    }
}