package util;


import main.SystemHelper;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;

public class Client {

    private String clientHandshakeString;
    private String clientName;
    private BufferedReader in;
    private DataOutputStream out;
    private int lowerBound;
    private int upperBound;
    private byte[] program;

    public Client (BufferedReader in, DataOutputStream out, int lowerBound, int upperBound, byte[] program) {
        try {
            //make in and out global
            this.in = in;
            this.out = out;

            //assign the range + byte[]
            this.lowerBound = lowerBound;
            this.upperBound = upperBound;
            this.program = program;

            //connect
            setUp();

        } catch (Exception e) {
            System.err.println("Internal Error Related to Client Creation:");
            e.printStackTrace();
        }
    }

    public BufferedReader getIn() { return in; }
    public DataOutputStream getOut() { return out; }

    private void setUp()
    {
        try {
            //perform handshake
            clientName = in.readLine();
            clientHandshakeString = in.readLine();
            SystemHelper.print("Established a connection with client: "+clientName);
            SystemHelper.print("Received Handshake Word: " + clientHandshakeString);
            SystemHelper.print("Sending Response Word: "+clientHandshakeString.toUpperCase());
            out.writeBytes(clientHandshakeString.toUpperCase() + '\n');

            //send range
            SystemHelper.print("Setting range from: "+lowerBound+" to "+upperBound);
            out.writeBytes(lowerBound+"\n");
            out.writeBytes(upperBound+"\n");

            //send the executable
            out.writeBytes(program.length+"\n");
            SystemHelper.print("Executable has file length: "+program.length);

            String res = "";
            for(byte b:program){
                out.writeBytes("" + b + '\n');
                res = res + b + " ";
            }
            SystemHelper.print(res);

            //Done doing this stuff
            SystemHelper.print("Done Connecting the Client");

        } catch (Exception e) {
            System.err.println("Internal Error Related to Connecting the Client:");
            e.printStackTrace();
        }
    }
}
