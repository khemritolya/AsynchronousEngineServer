package client;


import main.SystemHelper;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.util.ArrayList;

/*
    (c) 2016, khemritolya

    This class represents a client.
    It also handles all the data transfer between the user and server, in the nice form of a "client" class.

 */

public class Client {

    //globals
    private String clientHandshakeString;
    private String clientName;
    private BufferedReader in;
    private DataOutputStream out;
    private int lowerBound;
    private int upperBound;
    private String id;

    //constructor
    public Client (BufferedReader in, DataOutputStream out, int lowerBound, int upperBound, String id) {
        try {
            //make in and out global
            this.in = in;
            this.out = out;
            this.id = id;


            //assign the range + byte[]
            this.lowerBound = lowerBound;
            this.upperBound = upperBound;

        } catch (Exception e) {
            System.err.println("Internal Error Related to Client Creation:");
            e.printStackTrace();
        }
    }

    //getters maybe use in the future?
    public BufferedReader getIn() { return in; }
    public DataOutputStream getOut() { return out; }

    //handle connections
    public void setUp()
    {
        try {
            //perform handshake
            clientName = in.readLine();
            clientHandshakeString = in.readLine();
            SystemHelper.print("Established a connection with client: "+clientName);
            SystemHelper.print("Received Handshake Word: " + clientHandshakeString);
            SystemHelper.print("Sending Response Word: "+clientHandshakeString.toUpperCase());
            out.writeBytes(clientHandshakeString.toUpperCase() + '\n');

            //send range
            SystemHelper.print("Setting range from: "+lowerBound+" to "+upperBound);
            out.writeBytes(lowerBound+"\n");
            out.writeBytes(upperBound+"\n");

            //Done doing this stuff
            SystemHelper.print("Done Connecting the Client");

            //recive answer
            ArrayList<Integer> res = new ArrayList<>();
            int i = 0;
            while((i = Integer.parseInt(in.readLine())) != -1) {
                res.add(i);
            }

            SystemHelper.print("Client "+clientName+" Has completed Operation: "+res.toString());

        } catch (Exception e) {
            System.err.println("Internal Error related to the Client:");
            e.printStackTrace();
        }
    }
}
