package client;

import java.io.BufferedReader;
import java.io.DataOutputStream;

/*
    (c) 2016, khemritolya

    This class allows us to put each client on a separate thread, which has two benefits:

    1. It reduces load on the main thread.

    2. It makes constant checking of completion by the ServerController unnecessary.

 */

public class ClientExtender implements Runnable {

    //globals
    private Thread t;
    private Client client;

    private BufferedReader in;
    private DataOutputStream out;
    private int lowerBound;
    private int upperBound;
    private String id;

    //constructor
    public ClientExtender(BufferedReader in, DataOutputStream out, int lowerBound, int upperBound, String id) {
        this.in = in;
        this.out = out;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.id = id;
    }

    //runnable implementation
    public void run() {
        //create client + establish connection
        client = new Client(in, out, lowerBound, upperBound, id);
        client.setUp();
    }

    //start the thread
    public void start() {
        t = new Thread(this, id+"");
        t.start();
    }
}
